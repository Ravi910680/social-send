<?php
set_time_limit(0);
ignore_user_abort(true);
require("fb-post.php");



function httpPost($url,$params)
{
	$p=0;

  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';

$p=$p+1;
   }

   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, $p);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);
   

    curl_close($ch);
    return $output;
          
}  


function update_fun_for_tok_data($value,$flg){


  require("./confige/post_data_confige.php");

 $update_query="update post_que_data set flg_send='".$flg."' where token='".$value."'";


if ($social_post_conn->query($update_query) === TRUE) {

}


}







function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 

    $output=curl_exec($ch);
    curl_close($ch);
    return $output;
}


function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}

function get_late_camp(){

require("./confige/post_data_confige.php");


$sel_camp_data_query="select  url,img,text,post_name,min(date_time) from camp_soc_hy where flg_send='0' LIMIT 1";

$result = $social_post_conn->query($sel_camp_data_query);


  // output data of each row
$row = $result->fetch_assoc();




return $row;


}


function update_tw_acc($value){



	require("./confige/post_data_confige.php");



 $update_query="update camp_soc_hy set flg_send='1' where post_name='".$value."'";


if ($social_post_conn->query($update_query) === TRUE) {


echo "ravi";


}

}







function get_send_post(){
require("./confige/post_data_confige.php");

$row=get_late_camp();

print_r($row);



$late_time=get_curr_time();



$past=strtotime($row['min(date_time)']);



 


if($late_time>$past and $past!==""){

$sel_query_acc="select * from post_que_data where camp_name='".$row['post_name']."' and flg_send='1'";


$result = $social_post_conn->query($sel_query_acc);


if ($result->num_rows > 0) {
  // output data of each row


	      	
		while($row2 = $result->fetch_assoc()) {


$token_acc=$row2['token'];
$token_exp=explode("#", $token_acc);


$arr_of_post=array();



if(count($token_acc)==count($token_exp)){




	 if(!filter_var($row['url'], FILTER_VALIDATE_URL)){
$row['url']="";


	 }else{


$row['url']=$row['url']."#fb";


	 }





$token=explode("*", $token_acc);



$get_val=json_decode(fb_account_sheduled($token[0],$token[1],$row));

if($get_val->id==null){



send_post_by_insta();




}else{
	
	

update_fun_for_tok_data($acc_tok,'0');



}




























}else{



if(!filter_var($row['url'], FILTER_VALIDATE_URL)){
$row['url']="";


         }else{


$row['url']=$row['url']."#tw";


         }





	
	twitter_send_post($token_acc,$row);
}




  }
}


update_tw_acc($row['post_name']);









}



}









function twitter_send_post($acc_tok,$row){



	
$jsn_dec_post=json_encode($row);	
	
$acc_exp=explode("*", $acc_tok);



$acc_key_exp=explode("#", $acc_exp[0]);

$acc_det=$acc_exp[1];

$acc_tok=$acc_key_exp[0];

$acc_key_sec=$acc_key_exp[1];

$para_arr=array(

	"acc_det"=>$acc_det,
	"acc_tok"=>$acc_tok,
	"acc_tok_sec"=>$acc_key_sec,
	"post_data"=>$jsn_dec_post


	);

print_r($para_arr);

$url_data="https://heptera.me/dash/main/addcontact/emb/tw/send_post_req.php";


$get_data=httpPost($url_data,$para_arr);
update_fun_for_tok_data($acc_tok,$get_data);


}

while(true){

get_send_post();

}
?>


