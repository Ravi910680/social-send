<?php


$servername = "database-1.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "social_post";

$social_post_conn = mysqli_connect($servername, $username, $password,$dbname);

if ($social_post_conn ->connect_error) {
  die("Connection failed: " . $social_post_conn ->connect_error);
}


?>
